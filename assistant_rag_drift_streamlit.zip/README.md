# Assistant Règlement Drift 2025

Assistant IA (RAG) permettant d’interroger les règlements techniques et standards du Drift 2025.

## Fonctionnalités

- Posez des questions comme "Quelle est la règle pour les phares ?" ou "Qui gagne en cas de double abandon ?"
- L’IA répond uniquement sur la base des documents PDF fournis.
- Chaque réponse inclut une interprétation, la page, l’article et un extrait du règlement.

## Installation (Streamlit Cloud)

1. Cloner ce repo ou uploader manuellement sur GitHub.
2. Aller sur [https://streamlit.io/cloud](https://streamlit.io/cloud)
3. Créer une nouvelle application à partir du dépôt.
4. Ajouter la clé `OPENAI_API_KEY` dans les secrets (Settings > Secrets).
5. Lancer l’application.

## Dépendances
Listées dans `requirements.txt`.

## Fichiers inclus
- `assistant_drift.py` : script principal Streamlit
- Dossier `documents/` avec les PDF
